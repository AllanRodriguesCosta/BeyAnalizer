import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Part } from "@/hooks/usePartsStorage";

interface AddPartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (part: Omit<Part, "id">) => void;
}

export default function AddPartModal({ isOpen, onClose, onAdd }: AddPartModalProps) {
  const [partType, setPartType] = useState<"Blade" | "Ratchet" | "Bit" | "AssistBlade" | "">(
    ""
  );
  const [beyType, setBeyType] = useState<"BX" | "UX" | "CX" | "">("BX");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [stats, setStats] = useState({
    attack: 0,
    defense: 0,
    stamina: 0,
    dash: 0,
    burst: 0,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!partType || !beyType || !name) {
      alert("Por favor, preencha todos os campos obrigatórios");
      return;
    }

    const newPart: Omit<Part, "id"> = {
      name,
      type: partType as "Blade" | "Ratchet" | "Bit" | "AssistBlade",
      beyType: beyType as "BX" | "UX" | "CX",
      stats: {
        attack: stats.attack,
        defense: stats.defense,
        stamina: stats.stamina,
        ...(stats.dash > 0 && { dash: stats.dash }),
        ...(stats.burst > 0 && { burst: stats.burst }),
      },
      ...(description && { description }),
    };

    onAdd(newPart);
    resetForm();
    onClose();
  };

  const resetForm = () => {
    setPartType("");
    setBeyType("BX");
    setName("");
    setDescription("");
    setStats({
      attack: 0,
      defense: 0,
      stamina: 0,
      dash: 0,
      burst: 0,
    });
  };

  const handleStatChange = (stat: keyof typeof stats, value: number) => {
    setStats((prev) => ({
      ...prev,
      [stat]: value,
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-slate-800 border-purple-500 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle>Adicionar Nova Peça</DialogTitle>
          <DialogDescription className="text-purple-200">
            Preencha os dados da nova peça de Beyblade
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Tipo de Peça */}
          <div>
            <Label className="text-purple-300 mb-2 block">Tipo de Peça *</Label>
            <Select value={partType} onValueChange={(value: any) => setPartType(value)}>
              <SelectTrigger className="bg-slate-700 border-purple-400 text-white">
                <SelectValue placeholder="Selecione o tipo de peça" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-purple-400">
                <SelectItem value="Blade" className="text-white">
                  Blade (Lâmina)
                </SelectItem>
                <SelectItem value="Ratchet" className="text-white">
                  Ratchet (Eixo)
                </SelectItem>
                <SelectItem value="Bit" className="text-white">
                  Bit (Ponta)
                </SelectItem>
                <SelectItem value="AssistBlade" className="text-white">
                  Assist Blade (CX)
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tipo de Beyblade */}
          <div>
            <Label className="text-purple-300 mb-2 block">Tipo de Beyblade *</Label>
            <Select value={beyType} onValueChange={(value: any) => setBeyType(value)}>
              <SelectTrigger className="bg-slate-700 border-purple-400 text-white">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-purple-400">
                <SelectItem value="BX" className="text-white">
                  BX (Padrão)
                </SelectItem>
                <SelectItem value="UX" className="text-white">
                  UX (Padrão)
                </SelectItem>
                <SelectItem value="CX" className="text-white">
                  CX (Custom)
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Nome da Peça */}
          <div>
            <Label className="text-purple-300 mb-2 block">Nome da Peça *</Label>
            <Input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Soar Phoenix, 9-60, GF"
              className="bg-slate-700 border-purple-400 text-white placeholder:text-purple-400"
            />
          </div>

          {/* Descrição */}
          <div>
            <Label className="text-purple-300 mb-2 block">Descrição (Opcional)</Label>
            <Input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descrição da peça"
              className="bg-slate-700 border-purple-400 text-white placeholder:text-purple-400"
            />
          </div>

          {/* Atributos */}
          <div className="space-y-4">
            <Label className="text-purple-300 block font-semibold">Atributos</Label>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm text-purple-300 mb-1 block">Ataque</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={stats.attack}
                  onChange={(e) => handleStatChange("attack", parseInt(e.target.value) || 0)}
                  className="bg-slate-700 border-purple-400 text-white"
                />
              </div>

              <div>
                <Label className="text-sm text-purple-300 mb-1 block">Defesa</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={stats.defense}
                  onChange={(e) => handleStatChange("defense", parseInt(e.target.value) || 0)}
                  className="bg-slate-700 border-purple-400 text-white"
                />
              </div>

              <div>
                <Label className="text-sm text-purple-300 mb-1 block">Estamina</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={stats.stamina}
                  onChange={(e) => handleStatChange("stamina", parseInt(e.target.value) || 0)}
                  className="bg-slate-700 border-purple-400 text-white"
                />
              </div>

              <div>
                <Label className="text-sm text-purple-300 mb-1 block">Dash (Opcional)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={stats.dash}
                  onChange={(e) => handleStatChange("dash", parseInt(e.target.value) || 0)}
                  className="bg-slate-700 border-purple-400 text-white"
                />
              </div>

              <div>
                <Label className="text-sm text-purple-300 mb-1 block">Resistência a Burst (Opcional)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={stats.burst}
                  onChange={(e) => handleStatChange("burst", parseInt(e.target.value) || 0)}
                  className="bg-slate-700 border-purple-400 text-white"
                />
              </div>
            </div>
          </div>

          {/* Botões */}
          <div className="flex gap-4 justify-end pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-purple-400 text-purple-300 hover:bg-slate-700"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Adicionar Peça
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
