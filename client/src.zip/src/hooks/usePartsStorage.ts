import { useState, useEffect } from "react";

export interface Part {
  id: string;
  name: string;
  type: "Blade" | "Ratchet" | "Bit" | "AssistBlade";
  beyType: "BX" | "UX" | "CX";
  stats: {
    attack: number;
    defense: number;
    stamina: number;
    dash?: number;
    burst?: number;
  };
  description?: string;
}

export interface StorageData {
  blades: Part[];
  ratchets: Part[];
  bits: Part[];
  assistBlades: Part[];
}

const STORAGE_KEY = "beybladePartsData";

export function usePartsStorage() {
  const [storageData, setStorageData] = useState<StorageData | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = () => {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          setStorageData(parsed);
        } else {
          // Initialize with empty structure
          setStorageData({
            blades: [],
            ratchets: [],
            bits: [],
            assistBlades: [],
          });
        }
      } catch (error) {
        console.error("Failed to load storage data:", error);
        setStorageData({
          blades: [],
          ratchets: [],
          bits: [],
          assistBlades: [],
        });
      }
      setIsLoaded(true);
    };

    loadData();
  }, []);

  // Save data to localStorage
  const saveData = (data: StorageData) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      setStorageData(data);
    } catch (error) {
      console.error("Failed to save storage data:", error);
    }
  };

  // Add a new part
  const addPart = (part: Omit<Part, "id">) => {
    if (!storageData) return;

    const newPart: Part = {
      ...part,
      id: `${part.type}-${Date.now()}`,
    };

    const updated = { ...storageData };
    const key = `${part.type.toLowerCase()}s` as keyof StorageData;
    (updated[key] as Part[]).push(newPart);

    saveData(updated);
    return newPart;
  };

  // Delete a part
  const deletePart = (partId: string, partType: string) => {
    if (!storageData) return;

    const updated = { ...storageData };
    const key = `${partType.toLowerCase()}s` as keyof StorageData;
    (updated[key] as Part[]) = (updated[key] as Part[]).filter(
      (p) => p.id !== partId
    );

    saveData(updated);
  };

  // Update a part
  const updatePart = (partId: string, partType: string, updates: Partial<Part>) => {
    if (!storageData) return;

    const updated = { ...storageData };
    const key = `${partType.toLowerCase()}s` as keyof StorageData;
    const items = updated[key] as Part[];
    const index = items.findIndex((p) => p.id === partId);

    if (index !== -1) {
      items[index] = { ...items[index], ...updates };
      saveData(updated);
    }
  };

  // Export data as JSON
  const exportData = () => {
    if (!storageData) return null;
    return JSON.stringify(storageData, null, 2);
  };

  // Import data from JSON
  const importData = (jsonString: string) => {
    try {
      const imported = JSON.parse(jsonString);
      if (
        imported.blades &&
        imported.ratchets &&
        imported.bits &&
        imported.assistBlades
      ) {
        saveData(imported);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Failed to import data:", error);
      return false;
    }
  };

  return {
    storageData,
    isLoaded,
    addPart,
    deletePart,
    updatePart,
    exportData,
    importData,
  };
}
